
package recuparcial1alurralde;


public class RegistroSensor extends EvidenciaTecnica{
    private final double frecuenciaDetectada;
    
    
    public RegistroSensor(String codigo, String agenciaResponsable, NivelClasificacion nivel, String fechaObtencion, int nivelConfiabilidad, double frecuenciaDetectada) {
        super(codigo, agenciaResponsable, nivel, fechaObtencion, nivelConfiabilidad);
        this.frecuenciaDetectada = frecuenciaDetectada;
    }
    
    private void validarFrecuencia(double frecuencia){
        if(frecuencia <= 0){
            throw new IllegalArgumentException("La frecuencia no puede ser cero");
        }
    }

    public double getFrecuenciaDetectada() {
        return frecuenciaDetectada;
    }
    
    

    @Override
    public String getDescription() {
        return "Registro Sensor [codigo = "+getCodigo()+", agencia = "+getAgenciaResponsable()+", clasificacion = "+ getNivelClasificacion()+", \n"
                +"fechaObtencion ="+getFechaObtencion()+", confiabilidad = "+getNivelConfiabilidad()+",frecuencia detectada = "+getFrecuenciaDetectada()+"].";
    }
    
    
    
    
}
