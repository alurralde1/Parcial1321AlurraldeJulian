package recuparcial1alurralde;

import java.util.List;
import java.util.Objects;

public class RecuParcial1Alurralde {

    public static void main(String[] args) {

        ArchivoDesclasificado archivo = new ArchivoDesclasificado("Proyecto Disclosure");

        try {
            archivo.agregarArchivo(new InformeAvistamiento("UAP-101", "AARO", NivelClasificacion.ULTRASECRETO, "14/07/2024", 92, "Desierto de Nevada"));
            archivo.agregarArchivo(new RegistroSensor("SEN-205", "Fuerza Aerea", NivelClasificacion.RESERVADO, "03/09/2023", 78, 1420.5));
            archivo.agregarArchivo(new TestimonioClasificado("TES-308", "CIA", NivelClasificacion.PUBLICO, "Testigo Orion"));
            archivo.agregarArchivo(new RegistroSensor("SEN-410", "AARO", NivelClasificacion.ULTRASECRETO, "21/02/1015", 96, 3150.8));
            archivo.agregarArchivo(new InformeAvistamiento("UAP-101", "AARO", NivelClasificacion.RESERVADO, "10/10/2025", 65, "Roswell"));
        } catch (ArchivoDuplicadoException e) {
            System.out.println("No se pudo agregar el archivo: " + e.getMessage());
        }

        System.out.println("Archivos registrados:");
        mostrarArchivos(archivo.obtenerArchivos());

        System.out.println();

        int analizables = analizarArchivos(archivo.obtenerArchivos());

        System.out.println("Cantidad de archivos analizables: " + analizables);

        System.out.println();

        int informes = generarInformes(archivo.obtenerArchivos());

        System.out.println("Cantidad de informes generados: " + informes);

        System.out.println();

        System.out.println("Archivos ULTRASECRETOS:");

        mostrarArchivos(archivo.filtrarPorNivel(NivelClasificacion.ULTRASECRETO));

    }

    private static void mostrarArchivos(List<Archivo> archivos) {
        if (archivos.isEmpty()) {
            System.out.println("No hay archivos para mostrar.");
            return;
        }

        for (Archivo archivo : archivos) {
            Objects.requireNonNull(archivo);
            System.out.println(archivo);
        }
    }

    private static int analizarArchivos(List<Archivo> archivos) {

        int cantidad = 0;

        for (Archivo archivo : archivos) {
            Objects.requireNonNull(archivo);

            if (archivo instanceof Analizable analizable) {
                System.out.println(analizable.analizar());
                cantidad++;
            } else {
                System.out.println("El archivo '" + archivo.getCodigo() + "' no puede analizarse como " + "evidencia tecnica."); 
            } 
        } 
        return cantidad;
    }

    private static int generarInformes(List<Archivo> archivos) {

        int cantidad = 0;

        for (Archivo archivo : archivos) {
            Objects.requireNonNull(archivo);

            if (archivo instanceof Informable informable) {
                System.out.println(informable.generarInforme());
                cantidad++;
            } else {
                System.out.println("El archivo '" + archivo.getCodigo() + "' no generainforme."); 
            } 
        } 
        return cantidad;
    }

}
