
package recuparcial1alurralde;


public class ArchivoDuplicadoException extends Exception{
    public static final String MESSAGE = "Ya existe el archivo ";
    
    public ArchivoDuplicadoException(){
        this(MESSAGE);
    }
    
    public ArchivoDuplicadoException(String mensaje){
        super(mensaje);
    }
}
