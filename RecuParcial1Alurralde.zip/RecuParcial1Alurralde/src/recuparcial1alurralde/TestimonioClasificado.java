
package recuparcial1alurralde;


public class TestimonioClasificado extends Archivo{
    private final String alias;
    
    public TestimonioClasificado(String codigo, String agenciaResponsable, NivelClasificacion nivel,String alias) {
        super(codigo, agenciaResponsable, nivel);
        validarString(alias);
        this.alias = alias;
    }
    
    private void validarString(String string){
        if(string == null || string.isEmpty()){
            throw new IllegalArgumentException("La ubicacion del fenomeno no puede ser nula");
        }
    }

    public String getAlias() {
        return alias;
    }

    @Override
    public String getDescription() {
        return "Testimonio [codigo = "+getCodigo()+", agencia = "+getAgenciaResponsable()+", clasificacion = "+ getNivelClasificacion()+", \n"
                +"alias = "+getAlias()+"].";
    }
    
    
}
