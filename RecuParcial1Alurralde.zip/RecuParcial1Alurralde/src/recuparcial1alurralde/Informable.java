
package recuparcial1alurralde;


public interface Informable {
    String generarInforme();
}
