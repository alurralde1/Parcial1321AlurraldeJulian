
package recuparcial1alurralde;


public interface Analizable {
    String analizar();
    
}
