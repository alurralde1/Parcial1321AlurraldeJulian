
package recuparcial1alurralde;

import java.util.ArrayList;
import java.util.List;


public class ArchivoDesclasificado {
    private final String nombre;
    private final List<Archivo> archivos;
    
    public ArchivoDesclasificado(String nombre){
        validarNombre(nombre);
        this.nombre = nombre;
        archivos = new ArrayList<>();
    }
    
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isEmpty()){
            throw new IllegalArgumentException("El nombre del archivo no puede estar vacio");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    
    /***
     * Se agrega un Archivo a los archivos desclasificados.
     * 
     * Dos archivos son repetidos si tienen el mismo codigo y la misma agencia responsable.
     * La comparacion se realiza a traves del metodo equals de la clase Archivo.
     * 
     * @param archivo Archivo que se desea agregar
     * @throws ArchivoDuplicadoException Si el archivo ya existe en los archivo desclasificados
     */
    public void agregarArchivo(Archivo archivo) throws ArchivoDuplicadoException{
        validarArchivo(archivo);
        validarArchivoRepetido(archivo);
        archivos.add(archivo);
    }
    
    private void validarArchivo(Archivo archivo){
        if(archivo == null){
            throw new IllegalArgumentException("El archivo no puede ser null.");
        }
    }
    
    private void validarArchivoRepetido(Archivo archivo) throws ArchivoDuplicadoException{
        if(archivos.contains(archivo)){
            throw new ArchivoDuplicadoException("No se pudo agregar el archivo: Ya existe un archivo con codigo '"+ archivo.getCodigo()+"' perteneciente a la agencia '"+archivo.getAgenciaResponsable()+"'.");
        }
    }
    
    public List<Archivo> obtenerArchivos(){
        return new ArrayList<>(archivos);
    }
    
    /***
     * Devuelve los archivos que coinciden con el nivel de clasificacion que se pasa por parametro.
     * 
     * @param nivel nivel de clasificacion a comparar para filtrar
     * @return lista de archivos que tienen el nivel a comparar
     */
    public List<Archivo> filtrarPorNivel(NivelClasificacion nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de intensidad no puede ser null.");
        }
        
        List<Archivo> filtrado = new ArrayList<>();
        
        for(Archivo file: archivos){
            if(file.getNivelClasificacion()== nivel){
                filtrado.add(file);
            }
        }
        
        return filtrado;
        
    }
}
