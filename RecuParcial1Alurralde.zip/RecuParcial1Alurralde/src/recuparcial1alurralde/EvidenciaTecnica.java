
package recuparcial1alurralde;


public abstract class EvidenciaTecnica extends Archivo implements Analizable{
    private static final int MAX_NIV_CONF = 100;
    private static final int MIN_NIV_CONF = 0;
    private final String fechaObtencion;
    private final int nivelConfiabilidad;
    
    
    public EvidenciaTecnica(String codigo, String agenciaResponsable, NivelClasificacion nivel,String fechaObtencion, int nivelConfiabilidad) {
        super(codigo, agenciaResponsable, nivel);
        checkNull(codigo);
        validarNivelConfiabilidad(nivelConfiabilidad);
        this.fechaObtencion = fechaObtencion;
        this.nivelConfiabilidad = nivelConfiabilidad;
    }
    
    private void checkNull(String fecha){
        if(fecha == null || fecha.isEmpty()){
            throw new IllegalArgumentException("La fecha no puede ser null.");
        }
    }
    
    private void validarNivelConfiabilidad(int nivel){
        if(nivel < MIN_NIV_CONF && nivel > MAX_NIV_CONF){
            throw new IllegalArgumentException("El puntaje no puede ser menor que 0 y tampoco puede ser mayor a 100");
        }
    }

    public String getFechaObtencion() {
        return fechaObtencion;
    }

    public int getNivelConfiabilidad() {
        return nivelConfiabilidad;
    }
    
    public String analizar(){
        return "Se analizo la evidencia: "+getCodigo()+ "Con un nivel de confiabilidad de "+getNivelConfiabilidad()+"%.";
    }
    
    
    
}
