
package recuparcial1alurralde;


public enum NivelClasificacion {
    PUBLICO,
    RESERVADO,
    ULTRASECRETO
}
