
package recuparcial1alurralde;

import java.util.Objects;


public abstract class Archivo {
    private final String codigo;
    private final String agenciaResponsable;
    private final NivelClasificacion nivel;

    public Archivo(String codigo, String agenciaResponsable, NivelClasificacion nivel) {
        validarString(codigo,"El codigo no puede estar vacio");
        validarString(agenciaResponsable, "La agencia no puede estar vacia");
        validarNivel(nivel);
        
        this.codigo = codigo;
        this.agenciaResponsable = agenciaResponsable;
        this.nivel = nivel;
    }
    
    private void validarString(String string,String mensaje){
        if(string == null || string.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarNivel(NivelClasificacion nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de clasificacion no puede ser null");
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getAgenciaResponsable() {
        return agenciaResponsable;
    }

    public NivelClasificacion getNivelClasificacion() {
        return nivel;
    }
    
    public abstract String getDescription();

    @Override
    public String toString() {
       return getDescription();
    }

    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Archivo a)){
            return false;
        }
        return codigo.equals(a.codigo) && agenciaResponsable.equals(a.agenciaResponsable);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(codigo, agenciaResponsable);
    }
}
