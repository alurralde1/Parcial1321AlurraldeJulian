
package recuparcial1alurralde;


public class InformeAvistamiento extends EvidenciaTecnica{
    private final String ubicacionFenomeno;
    
    public InformeAvistamiento(String codigo, String agenciaResponsable, NivelClasificacion nivel, String fechaObtencion, int nivelConfiabilidad, String ubicacionFenomeno) {
        super(codigo, agenciaResponsable, nivel, fechaObtencion, nivelConfiabilidad);
        validarString(ubicacionFenomeno);
        this.ubicacionFenomeno = ubicacionFenomeno;
    }
    
    private void validarString(String string){
        if(string == null || string.isEmpty()){
            throw new IllegalArgumentException("La ubicacion del fenomeno no puede ser nula");
        }
    }

    public String getUbicacionFenomeno() {
        return ubicacionFenomeno;
    }
    

    @Override
    public String getDescription() {
        return "Informe Avistamiento [codigo = "+getCodigo()+", agencia = "+getAgenciaResponsable()+", clasificacion = "+ getNivelClasificacion()+", \n"
                +"fechaObtencion ="+getFechaObtencion()+", confiabilidad = "+getNivelConfiabilidad()+",ubicacion = "+getUbicacionFenomeno()+"].";
    }
    
    
    
}
