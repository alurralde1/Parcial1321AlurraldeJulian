
package primerparcial;


public class ClaseGrupal extends Actividad implements Programable{
    private final int cantMaxParticipantes;

    public ClaseGrupal(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad, int cantMaxParticipantes) {
        super(nombre, entrenadorResponsable, nivelIntensidad);
        validarParticipantes(cantMaxParticipantes);
        this.cantMaxParticipantes = cantMaxParticipantes;
    }
    
    private void validarParticipantes(int participantes){
        if(participantes <= 0){
            throw new IllegalArgumentException("La cantidad maxima de participantes tiene que ser mayo a 0.");
        }
    }
    
    public int getCantMaxParticipantes(){
        return cantMaxParticipantes;
    }

    @Override
    public String getDescription() {
        return "Clase Grupal: [nombre = "+ getNombre()+", entrenador = "+getEntrenadorResponsable()+", intensidad = "+getNivelIntensidad()+", cantParticipantes = "+cantMaxParticipantes+"].";
    }
    
    @Override
    public String programar(){
        return "Se programo la clase grupal: " + getNombre();
    }
}
