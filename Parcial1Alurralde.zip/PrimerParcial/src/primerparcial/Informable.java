
package primerparcial;


public interface Informable {
    String generarInforme();
}
