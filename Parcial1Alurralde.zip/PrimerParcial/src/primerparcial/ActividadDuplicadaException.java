
package primerparcial;


public class ActividadDuplicadaException extends Exception{
     public static final String MESSAGE = "Ya existe la actividad con el mismo nombre y el mismo entrenador responsable";
    
    public ActividadDuplicadaException(){
        this(MESSAGE);
    }
    
    public ActividadDuplicadaException(String mensaje){
        super(mensaje);
    }
}
