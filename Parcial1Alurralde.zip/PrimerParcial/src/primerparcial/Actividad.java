
package primerparcial;

import java.util.Objects;

/***
 * Represanta una actividad general dentro de un centro de entrenamiento
 * 
 * Una actividad tiene un nombre, un entrenador responsable y un nivel de intensidad.
 * Esta clase es abstracta porque en el sistema no se registran actividades genericas, 
 * sino actividades concretas como clases grupales, rutinas personalizadaso evaluaciones fisicas.
 */

public abstract class Actividad {
    private final String nombre;
    private final String entrenadorResponsable;
    private final NivelIntensidad nivelIntensidad;

    public Actividad(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad) {
        validarString(nombre,"El nombre de la actividad no puede ser nulo");
        validarString(entrenadorResponsable,"El entrenador responsable no puede estar vacio");
        validarNivel(nivelIntensidad);
        this.nombre = nombre;
        this.entrenadorResponsable = entrenadorResponsable;
        this.nivelIntensidad = nivelIntensidad;
    }
    
    private void validarString(String palabra, String mensaje){
        if(palabra == null || palabra.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarNivel(NivelIntensidad nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de intensidad no puede ser null.");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getEntrenadorResponsable(){
        return entrenadorResponsable;
    }
    
    public NivelIntensidad getNivelIntensidad(){
        return nivelIntensidad;
    }
    
    public abstract String getDescription();

    @Override
    public String toString() {
       return getDescription();
    }

    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Actividad a)){
            return false;
        }
        return nombre.equals(a.getNombre()) && entrenadorResponsable.equals(a.entrenadorResponsable);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, entrenadorResponsable);
    }
    
    
}
