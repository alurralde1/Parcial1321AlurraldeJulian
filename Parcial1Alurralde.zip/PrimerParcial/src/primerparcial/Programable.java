
package primerparcial;


public interface Programable {
    String programar();
}
