
package primerparcial;


public class EvaluacionFisica extends Actividad implements Informable{
    private static final int PUNTAJE_MIN = 0;
    private static final int PUNTAJE_MAX = 100;
    private final int puntaje;

    public EvaluacionFisica(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad,int puntaje) {
        super(nombre, entrenadorResponsable, nivelIntensidad);
        validarPuntaje(puntaje);
        this.puntaje = puntaje;
    }
    
    private void validarPuntaje(int puntaje){
        if(puntaje < PUNTAJE_MIN && puntaje > PUNTAJE_MAX ){
            throw new IllegalArgumentException("Error , el puntaje no puede ser menor que 0 o mayor que 100");
        }
    }
    
    public int getPuntaje(){
        return puntaje;
    }
    
    
    @Override
    public String generarInforme(){
        return "Informe de evaluacion fisica: "+getNombre()+ ". Puntaje obtenido: "+ puntaje+"/100.";
    }

    @Override
    public String getDescription() {
        return "Evalucacion Fisica: [nombre = "+ getNombre()+", entrenador = "+getEntrenadorResponsable()+", intensidad = "+getNivelIntensidad()+", puntaje = "+getPuntaje()+"].";
    }
    
    
    
    
}
