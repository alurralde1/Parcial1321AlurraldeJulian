
package primerparcial;


public class RutinaPersonalizada extends Actividad implements Programable, Informable{
    private final int duracionSemanas;

    public RutinaPersonalizada(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad, int duracionSemanas) {
        super(nombre, entrenadorResponsable, nivelIntensidad);
        validarDuracion(duracionSemanas);
        this.duracionSemanas = duracionSemanas;
    }
    
    private void validarDuracion(int duracion){
        if(duracion <= 0){
            throw new IllegalArgumentException("La duracion estimada en semanas tiene que ser mayor a cero");
        }
    }
    public int getDuracionSemanas(){
        return duracionSemanas;
    }
    
    @Override
    public String programar(){
        return "Se programo la rutina personalizada: "+getNombre();
    }
    
    @Override
    public String generarInforme(){
        return "Informe de rutina personalizada: "+ getNombre()+". Duracion estimada: "+ duracionSemanas + " semanas.";
    }
    
    @Override
    public String getDescription() {
        return "RutinaPersonalizada: [nombre = "+ getNombre()+", entrenador = "+getEntrenadorResponsable()+", intensidad = "+getNivelIntensidad()+", duracionSemanas = "+duracionSemanas+"].";
    }
    
    
}
