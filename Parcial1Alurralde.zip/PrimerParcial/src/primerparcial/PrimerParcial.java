
package primerparcial;

import java.util.List;
import java.util.Objects;


public class PrimerParcial {

    
    public static void main(String[] args) {
        CentroEntrenamiento centro = new CentroEntrenamiento("Alto Rendimiento Sur"); 
        
        try {
            centro.agregarActividad(new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25));
            
            centro.agregarActividad(new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz", NivelIntensidad.MEDIA,8));
            
            centro.agregarActividad(new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez", NivelIntensidad.BAJA, 78));
            
            centro.agregarActividad(new RutinaPersonalizada("Plan Resistencia", "Laura Gomez", NivelIntensidad.ALTA,6));
            
            centro.agregarActividad(new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20));

        } catch (ActividadDuplicadaException e) {
            System.out.println("No se pudo generar la actividad: "+ e.getMessage());
        }
        
        System.out.println("Actividades Registradas: ");
        mostrarActividades(centro.obtenerActividades());
        
        System.out.println("Actividades Programables:");
        programarActividades(centro.obtenerActividades());
        
        System.out.println("Informes Generados: ");
        generarInforme(centro.obtenerActividades());
        
        System.out.println("Actividades de intensidad Alta: ");
        mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA));
    }
    
    
    private static void mostrarActividades(List<Actividad> actividades){
        if(actividades.isEmpty()){
            System.out.println("No hay actividades para mostrar.");
        }else{
            for(Actividad actividad: actividades){
                System.out.println(actividad);
            }
        }
    }
    
    public static void programarActividades(List<Actividad> actividades){
        for(Actividad actividad: actividades){
            Objects.requireNonNull(actividad);
            if(actividad instanceof Programable programable){
            System.out.println(programable.programar());
            }else {
                System.out.println("La actividad '"+ actividad.getNombre()+"' no se puede programar.");
            }
        }
    }
    
    public static void generarInforme(List<Actividad> actividades){
        for(Actividad actividad: actividades){
            Objects.requireNonNull(actividad);
            if(actividad instanceof Informable informable){
                System.out.println(informable.generarInforme());
            } else {
                System.out.println("La actividad '"+actividad.getNombre()+"' no genera informes");
            }
        }
    }
    
}
