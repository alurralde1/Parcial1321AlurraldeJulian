
package primerparcial;

import java.util.ArrayList;
import java.util.List;


public class CentroEntrenamiento {
    private final String nombre;
    private final List<Actividad> actividades;
    
    public CentroEntrenamiento(String nombre){
        validarNombre(nombre);
        this.nombre = nombre;
        actividades = new ArrayList<>();
    }
    
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del centro no puede estar vacio");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    /***
     * Se agrega una actividad al centro de entrenamiento.
     * 
     * Dos actividades son repetidas si tienen el mismo nombre y el mismo entrenador responsable.
     * La comparacion se realiza a traves del metodo equals de la clase Actividad.
     * 
     * @param actividad actividad que se desea agregar
     * @throws ActividadDuplicadaException Si la actividad ya existe en el centro
     */
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException{
        validarActividad(actividad);
        validarActividadRepetida(actividad);
        actividades.add(actividad);
    }
    
    private void validarActividad(Actividad actividad){
        if(actividad == null){
            throw new IllegalArgumentException("La actividad no puede ser null");
        }
    }
    
    private void validarActividadRepetida(Actividad actividad) throws ActividadDuplicadaException{
        if(actividades.contains(actividad)){
            throw new ActividadDuplicadaException("Ya existe una actividad con el nombre: '"+ actividad.getNombre()+"' y el entrenador Responsable: '"+actividad.getEntrenadorResponsable()+"'.");
        }
    }
    
    
    public List<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);
    }
    
    /***
     * Devuelve las actividades que coinciden con el nivel de intensidad que se paso por parametro
     * 
     * @param nivel nivel de intensidad a comparar para filtrar
     * @return lista de actividades que tienen el nivel a comparar
     */
    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de intensidad no puede ser null.");
        }
        
        List<Actividad> filtrado = new ArrayList<>();
        
        for(Actividad actividad: actividades){
            if(actividad.getNivelIntensidad() == nivel){
                filtrado.add(actividad);
            }
        }
        
        return filtrado;
        
    }
    
}
